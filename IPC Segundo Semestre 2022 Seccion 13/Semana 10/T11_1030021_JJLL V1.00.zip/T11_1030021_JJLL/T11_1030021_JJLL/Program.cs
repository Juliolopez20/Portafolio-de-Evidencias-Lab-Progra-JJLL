﻿using System;

namespace T11_1030021_JJLL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Programacion Orientada a objetos");

            Motocicleta objMotocicleta = new Motocicleta();
            Console.WriteLine(objMotocicleta.marca);
            Console.ReadKey();

            bool salir = false;

            while(!salir)
            {
                Console.Clear();
                Console.WriteLine(" Opcion 1: mostrar datos de la motocicleta ");
                Console.WriteLine(" Opcion 2: Modificar marca");
                Console.WriteLine(" Opcion 3: modificar Iva ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        Console.WriteLine("----Datos----");
                        string mensaje = objMotocicleta.mostrarDatos(objMotocicleta);
                        Console.WriteLine(mensaje);
                        Console.ReadKey();
                        break;

                    case "2":

                        Console.WriteLine("----Modificar Marca----");
                        Console.WriteLine(" Ingrese la marca ");
                        string nuevaMarca = Console.ReadLine();
                        objMotocicleta.marca = nuevaMarca;
                        break;
                    case "3":
                        Console.WriteLine("----Modificar Iva----");
                        Console.WriteLine(" Ingrese el valor del Iva que debe estar entre 0.1 a 0.99 ");
                        double nuevoIva = Convert.ToDouble(Console.ReadLine());

                        objMotocicleta.definirIva(nuevoIva);
                        break;

                    default:
                        break;


                }

            }
        }

    }

    class Motocicleta
    {
         public string marca = "DUCATI";
        private int modelo = 2019;
        double precio = 1000.00;
        double iva = 0.12;


        public void definirPrecio(int nuevoPrecio)
        {
            precio = nuevoPrecio;

        }

        public void definirIva(double nuevoIva)
        {

            if(nuevoIva >0 && nuevoIva <=0.99)
            {
                iva = nuevoIva;
                Console.WriteLine(" Iva actualizado");

            }
            else
            {
                Console.WriteLine("Error: el valor de Iva ingresado es incorrecto, debe de ser entre 0.1 a 0.99");
            }
            Console.ReadKey();
            
        }

        public string mostrarDatos(Motocicleta moto)
        {
            string mensaje = " Motocicleta marca: " + moto.marca;
            mensaje += " con precio " + moto.precioConIva().ToString();
            mensaje += " GTQ. *Iva incluido";
            return mensaje;
        }


        public double precioSinIva()
        {
            return precio;
        }


        public double precioConIva()
        {
            double montoIva = precio * iva;
            double montoConIva = precio + montoIva;
            return montoConIva;

        }

        public double devolverIva()
        {
            return precio * iva;
        }
    }
}
