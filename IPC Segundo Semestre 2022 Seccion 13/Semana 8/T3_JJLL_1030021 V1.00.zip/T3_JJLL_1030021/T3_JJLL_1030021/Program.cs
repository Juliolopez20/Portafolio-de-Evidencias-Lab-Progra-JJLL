﻿using System;

namespace T3_JJLL_1030021
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0;
            Console.WriteLine("Ejercicio 1 ");
            
            Console.WriteLine("Ingrese un numero: ");
            string ValorIngresado = Console.ReadLine();
            int y = Convert.ToInt16(ValorIngresado);


            if (y > 0)
            {
                Console.WriteLine("Resultado: El numero es positivo ");
            }
            else if (y < 0)
            {
                Console.WriteLine("Resultado: El numero es negativo ");
            }
            if (y == 0)
            {
                Console.WriteLine("Resultado: El numero es igual a 0");
            }
        }
    }
}
