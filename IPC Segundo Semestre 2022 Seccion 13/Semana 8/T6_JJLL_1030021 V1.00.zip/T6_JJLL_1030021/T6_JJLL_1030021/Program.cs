﻿using System;

namespace T6_JJLL_1030021
{
    class Program
    {
        static void Main(string[] args)
        {
            int dia, mes, año;

            Console.WriteLine("Ingrese su dia de nacimiento");
            dia = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el valor del mes de su nacimiento");
            mes = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese su año de nacimiento");
            año = int.Parse(Console.ReadLine());

            if(dia>=21 && mes==3 ||dia<=20 && mes==4)
            {
                Console.WriteLine("Su signo del Zodiaco es: Aries ");
            }
            if (dia >= 21 && mes == 4 || dia <= 21 && mes == 5)
            {
                Console.WriteLine("Su signo del Zodiaco es: Tauro ");
            }
            if (dia >= 22 && mes == 5 || dia <= 21 && mes == 6)
            {
                Console.WriteLine("Su signo del Zodiaco es: Geminis ");
            }
            if (dia >= 21 && mes == 6 || dia <= 23 && mes == 7)
            {
                Console.WriteLine("Su signo del Zodiaco es: Cancer ");
            }
            if (dia >= 24 && mes == 7 || dia <= 23 && mes == 8)
            {
                Console.WriteLine("Su signo del Zodiaco es: Leo ");
            }
            if (dia >= 24 && mes == 8 || dia <= 23 && mes == 9)
            {
                Console.WriteLine("Su signo del Zodiaco es: Virgo ");
            }
            if (dia >= 24 && mes == 9 || dia <= 23 && mes == 10)
            {
                Console.WriteLine("Su signo del Zodiaco es: Libra ");
            }
            if (dia >= 24 && mes == 10 || dia <= 22 && mes == 11)
            {
                Console.WriteLine("Su signo del Zodiaco es: Escorpio ");
            }
            if (dia >= 23 && mes == 11 || dia <= 21 && mes == 12)
            {
                Console.WriteLine("Su signo del Zodiaco es: Sagitario ");
            }
            if (dia >= 22 && mes == 12 || dia <= 20 && mes == 1)
            {
                Console.WriteLine("Su signo del Zodiaco es: Capricornio ");
            }
            if (dia >= 24 && mes == 8 || dia <= 19 && mes == 2)
            {
                Console.WriteLine("Su signo del Zodiaco es: Acuario ");
            }
            if (dia >= 20 && mes == 2 || dia <= 20 && mes == 3)
            {
                Console.WriteLine("Su signo del Zodiaco es: Piscis ");
            }

            Console.ReadKey();

        }
    }
}
