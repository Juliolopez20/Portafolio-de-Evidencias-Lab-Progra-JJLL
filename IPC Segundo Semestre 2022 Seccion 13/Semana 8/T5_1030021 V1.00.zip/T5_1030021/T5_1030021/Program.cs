﻿using System;

namespace T5_1030021
{
    class Program
    {
        static void Main(string[] args)
        {

            int a, b, c;
            Console.WriteLine("Ejercicio 3");

            Console.WriteLine("Ingrese el primer número");
            a = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Ingrese el segundo número");
            b = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Ingrese el tercer número");
            c = Convert.ToInt16(Console.ReadLine());


            if (a > b)
            {
                if (a > c)
                    Console.WriteLine("El número mayor es: " + a);
                else if (a == c)
                    Console.WriteLine("El número mayor es: " + a);
                else
                    Console.WriteLine("El número mayor es: " + c);
                Console.ReadLine();
            }
            else if (a == b)
            {
                if (a > c)
                    Console.WriteLine("El número mayor es: " + a );
                else if (a  == c)
                    Console.WriteLine("El número mayor es: " + a );
                else
                    Console.WriteLine("El número mayor es: " + c);
                Console.ReadLine();
            }
            else if (b > c)
                Console.WriteLine("El número mayor es: " + b);
            else if (b == c)
                Console.WriteLine("El número mayor es: " + b);
            else
                Console.WriteLine("El número mayor es: " + c);
            Console.ReadLine();

            Console.ReadKey();

        }
    }
}
