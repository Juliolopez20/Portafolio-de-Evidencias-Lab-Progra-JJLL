﻿using System;

namespace T4_1030021
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Programa 2 Semana 8");
            Console.WriteLine("Ingrese un numero del 1 al 7 para indicar el dia de la semana");
            String _valor = Console.ReadLine();
            int dia = Convert.ToInt16(_valor);
           

            if (dia >= 1 && dia<9)
            {
                if (dia == 1)
                {
                    Console.WriteLine("Lunes");

                }
                if (dia == 2)
                {
                    Console.WriteLine("Martes");

                }
                if (dia == 3)
                {
                    Console.WriteLine("Miercoles");

                }
                if (dia == 4)
                {
                    Console.WriteLine("Jueves");

                }
                if (dia == 5)
                {
                    Console.WriteLine("Viernes");

                }
                if (dia == 6)
                {
                    Console.WriteLine("Sabado");

                }
                if (dia == 7)
                {
                    Console.WriteLine("Domingo");

                }
            }
            else
            {
                Console.WriteLine("El valor ingresado no es valido");
            }

            Console.ReadKey();
        }


    }
}
