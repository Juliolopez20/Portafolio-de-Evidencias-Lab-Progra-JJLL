﻿using System;

namespace Proyecto_2._0._0
{
    class Program
    {
        static void Main()
        {

            //PREGUNTAS DE CODIGO. 200 PUNTOS CADA UNA
            String[] preguntasCod = new String[16];


            String[] carnets = new String[8];
            String[] nombres = new String[8];
            String[] apellidos = new String[8];
            int[] notas = new int[8];

            String respuesta;
            int contador = 0;
            int respuestasBuenas = 0;
            int respuestasMalas = 0;
            // Inicio Programa

            bool inicio = true;
            String menu = "PantallaPrincipal";

            while (inicio)
            {
                switch (menu)
                {
                    case "PantallaPrincipal":
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine(".......................................................................................................................................................................");
                        Console.WriteLine("..00..00..000000..000000..000000..000000..00..00..000000..000000..00..00..000000..000000....00000...000000.....000000..000000..000000..00..00..00000...000000...0000...");
                        Console.WriteLine("..00..00..00......00..00..00..00..00..00..000000....00....00......0000.0....00....00..00....00..00..00.........00......00........00....00..00..00..00....00....00..00..");
                        Console.WriteLine("..000000..0000....000000..000000..000000..00..00....00....0000....00.000....00....000000....00..00..0000.......0000....000000....00....00..00..00..00....00....00..00..");
                        Console.WriteLine("..00..00..00......0000....0000....00..00..00..00....00....00......00..00....00....00..00....00..00..00.........00..........00....00....00..00..00..00....00....00..00..");
                        Console.WriteLine("..00..00..000000..00..00..00..00..00..00..00..00..000000..000000..00..00....00....00..00....00000...000000.....000000..000000....00....000000..00000...000000...0000...");
                        Console.WriteLine(".......................................................................................................................................................................");
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        Console.Write("Presione ENTER para continuar");
                        Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Ingresa su nombre");
                        nombres[contador] = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        Console.WriteLine("Ingresa su apellido");
                        apellidos[contador] = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Gray;

                        carnet:
                        Console.WriteLine("Ingrese Carnet");
                        String carnet = Console.ReadLine();

                        
                        if (carnet[5] == '2' && carnet[6] == '2')
                        {
                            Console.WriteLine("Es de primer Ingreso");
                        }
                        else
                        {
                            Console.WriteLine("No es de primer Ingreso");
                            goto carnet;
                        }
                        carnets[contador] = carnet;
                        Console.ReadLine();
                        menu = "Pregunta1";
                        break;
                    case "Pregunta1":
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("***********************************  Pregunta #1  **********************************");
                        Console.WriteLine("Que paso mostrado a continuación pertenecen a la resolución de problemas de Software");
                        Console.WriteLine("************************************************************************************");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("A) Análisis");
                        Console.WriteLine("B) Elaborar");
                        Console.WriteLine("C) Ejecutar");
                        Console.WriteLine("D) Revisar");
                        Console.ForegroundColor = ConsoleColor.Red;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("A"))
                        {
                            notas[contador] += 50;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta2";
                        break;
                    case "Pregunta2":
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("***********************************  Pregunta #2  **********************************");
                        Console.WriteLine("*********** Elige cuál pertenecen a los 4 ejes del pensamiento computacional *******");
                        Console.WriteLine("************************************************************************************");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("A) Elaboracion");
                        Console.WriteLine("B) Recocimiento de Patrones");
                        Console.WriteLine("C) Elaboración de código");
                        Console.WriteLine("D) Diseño de ideas");
                        Console.ForegroundColor = ConsoleColor.Red;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("B"))
                        {
                            notas[contador] += 50;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta3";
                        break;
                    case "Pregunta3":
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("***********************************  Pregunta #3  **********************************");
                        Console.WriteLine("*************** Que Tipo de error está presente en los sistemas ********************");
                        Console.WriteLine("************************************************************************************");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("A) Errores de ejecución");
                        Console.WriteLine("B) Errores de sistema");
                        Console.WriteLine("C) Errores electricidad");
                        Console.WriteLine("D) Errores de color");
                        Console.ForegroundColor = ConsoleColor.Red;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("A"))
                        {
                            notas[contador] += 50;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta4";
                        break;
                    case "Pregunta4":
                        //Pregunta 4 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("***********************************  Pregunta #4  **********************************");
                        Console.WriteLine("********* Para trabajar con cadenas de texto se utilizan variables tipo:  **********");
                        Console.WriteLine("************************************************************************************");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("A) bool");
                        Console.WriteLine("B) String");
                        Console.WriteLine("C) int");
                        Console.WriteLine("D) double");
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("B"))
                        {
                            notas[contador] += 50;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta5";
                        break;
                    case "Pregunta5":
                        //Pregunta 5 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("***********************************  Pregunta #5  **********************************");
                        Console.WriteLine("*********+********* Nombres correctos para  declarar una variable:  ****************");
                        Console.WriteLine("************************************************************************************");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("A) _nombre");
                        Console.WriteLine("B) #s");
                        Console.WriteLine("C) 1a");
                        Console.WriteLine("D) $d");
                        Console.ForegroundColor = ConsoleColor.Red;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("A"))
                        {
                            notas[contador] += 50;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta6";
                        break;
                    case "Pregunta6":
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-----------------------------------  Pregunta #6  -----------------------------------");
                        Console.WriteLine("---  Para pasar información entre funciones es mejor utilizar variables globales. ---");
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("V) Verdadero");
                        Console.WriteLine("F) Falso");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("F"))
                        {
                            notas[contador] += 100;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta7";
                        break;
                    case "Pregunta7":
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("---------------------------------  Pregunta #7  -------------------------------------");
                        Console.WriteLine("---- Cuando unas funciones conocen mucho de otras funciones, pueden arriesgar su ---- \n" +
                                          "---- desempeño y tener efectos no deseados. -----------------------------------------");
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("V) Verdadero");
                        Console.WriteLine("F) Falso");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("V"))
                        {
                            notas[contador] += 100;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta8";
                        break;
                    case "Pregunta8":
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("------------------------------------  Pregunta #8  ----------------------------------");
                        Console.WriteLine("-----  Los objetos definidos dentro de una función no pueden ser -------------------- \n" +
                                          "-----  referenciados fuera de la función. -------------------------------------------");
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("V) Verdadero");
                        Console.WriteLine("F) Falso");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("V"))
                        {
                            notas[contador] += 100;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta9";
                        break;
                    case "Pregunta9":
                        //Pregunta 9 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("--------------------------------  Pregunta #9  --------------------------------------");
                        Console.WriteLine("----  Variables del tipo int, se utilizan para trabajar con numeros decimales. ------");
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("V) Verdadero");
                        Console.WriteLine("F) Falso");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("F"))
                        {
                            notas[contador] += 100;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta10";
                        break;
                    case "Pregunta10":
                        //Pregunta 10 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------  Pregunta #10  ---------------------------------------");
                        Console.WriteLine("----  El simbolo para concatenar texto es: =. ---------------------------------------");
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("V) Verdadero");
                        Console.WriteLine("F) Falso");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("F"))
                        {
                            notas[contador] += 100;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta11";
                        break;
                    case "Pregunta11":
                        //Pregunta 11 c#
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------  Pregunta #11  --------------------------------");
                        Console.WriteLine("----  ¿Cual es la salida del siguiente código? --------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("int a = 3;                                                                     ");
                        Console.WriteLine("String b = 6;                                                                  ");
                        Console.WriteLine("String c = 7                                                                    ");
                        Console.WriteLine("Console.WriteLine((a+b)*c);                                                      ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("A) 63");
                        Console.WriteLine("B) 24");
                        Console.WriteLine("C) 42");
                        Console.WriteLine("D) 222");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("D"))
                        {
                            notas[contador] += 200;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta12";
                        break;
                    case "Pregunta12":
                        //Pregunta 11 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("------------------------------------  Pregunta #12  ---------------------------------");
                        Console.WriteLine("----  ¿Cual es la salida del siguiente código? --------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("int a = 5;                                                                     ");
                        Console.WriteLine("int b = 2;                                                                  ");
                        Console.WriteLine("int division = a/b;                                                                    ");
                        Console.WriteLine("Console.WriteLine(division);                                                      ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("A) 3");
                        Console.WriteLine("B) 2.5");
                        Console.WriteLine("C) 2");
                        Console.WriteLine("D) Error");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("C"))
                        {
                            notas[contador] += 200;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta13";
                        break;
                    case "Pregunta13":
                        //Pregunta 11 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-----------------------------------  Pregunta #13  -------------------------------");
                        Console.WriteLine("----  ¿Cual es el valor de la variable entrada? --------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("int edad = 20;                                                                     ");
                        Console.WriteLine("double entrada = 45.78;                                                                  ");
                        Console.WriteLine("double promocion = 0.80;                                                      ");
                        Console.WriteLine("if(entrada=20){");
                        Console.WriteLine("    Console.WriteLine(entrada*promocion);                                   ");
                        Console.WriteLine("}                                                                    ");
                        Console.WriteLine("else(){                                                                    ");
                        Console.WriteLine("Console.WriteLine(entrada);                                                      ");
                        Console.WriteLine("}                                                                    ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("A) 45.78");
                        Console.WriteLine("B) 20");
                        Console.WriteLine("C) 16");
                        Console.WriteLine("D) 32");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("A"))
                        {
                            notas[contador] += 200;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta14";
                        break;
                    case "Pregunta14":
                        //Pregunta 11 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("------------------------------------  Pregunta #14  ---------------------------------");
                        Console.WriteLine("----  ¿Cual es la salida del siguiente código? --------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("String[] notasMusicales = new String[] { do, re, mi, fa, sol, la, si};                                                                     ");
                        Console.WriteLine("for(int i=0; i < 6; i++)                                                                  ");
                        Console.WriteLine("     Console.Write(notasMusicales[i]);                      ");
                        Console.WriteLine("}                                                                    ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("A) do re mi fa sol la");
                        Console.WriteLine("B) do re mi fa sol la si");
                        Console.WriteLine("C) doremifasolla");
                        Console.WriteLine("D) do, re, mi, fa, sol, la, si");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("C"))
                        {
                            notas[contador] += 200;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Pregunta15";
                        break;
                    case "Pregunta15":
                        //Pregunta 11 opcion multiple
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("------------------------------------  Pregunta #15  ---------------------------------");
                        Console.WriteLine("----  ¿Que tipo de error tiene el siguiente código? ---------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("String[] notasMusicales = new String[] { do, re, mi, fa, sol, la, si};                                                                     ");
                        Console.WriteLine("for(int i=0; i <= 7; i++)                                                                  ");
                        Console.WriteLine("     Console.Write(notasMusicales[i]);                      ");
                        Console.WriteLine("}                                                                    ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("A) No se puede usar .Write, unicamente .WriteLine");
                        Console.WriteLine("B) El vector no tiene el tamaño que dice el for");
                        Console.WriteLine("C) Se tiene que colocar comillas a toodo lo que esta adentro del .Wtrite()");
                        Console.WriteLine("D) No declaró bien el arreglo");
                        Console.ForegroundColor = ConsoleColor.Green;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("A"))
                        {
                            notas[contador] += 200;
                            respuestasBuenas++;
                        }
                        else
                        {
                            respuestasMalas++;
                        }
                        menu = "Resultados";
                        break;


                    case "Resultados":
                        int promedio = 0, media = 0, moda = 0;
                        Console.Clear();

                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------------");
                        Console.WriteLine("Respuestas malas: " + respuestasMalas);
                        Console.WriteLine("Respuestas buenas: " + respuestasBuenas);
                        Console.WriteLine("-------------------------------------------");
                        Console.WriteLine("--------------- RESULTAODS ----------------");
                        Console.WriteLine("-------------------------------------------");
                        Console.WriteLine("--NOMBRE-----APELLIDO-----CARNET-----NOTA--");
                        Console.WriteLine("-------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        for (int i = 0; i <= contador; i++)
                        {
                            Console.WriteLine("--" + nombres[i] + "--" + apellidos[i] + "--" + carnets[i] + "--" + notas[i] + "--");
                        }
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("-------------------------------------------");

                        for (int i = 0; i <= contador; i++)
                        {
                            promedio += notas[i];
                        }
                        promedio = promedio / (contador + 1);
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("Promedio: " + promedio);


                        //Operaciones
                        for (int x = 0; x <= contador; x++)
                        {
                            for (int i = 0; i <= contador - x - 1; i++)
                            {
                                if (notas[i] < notas[i + 1])
                                {
                                    int tmp = notas[i + 1];
                                    notas[i + 1] = notas[i];
                                    notas[i] = tmp;
                                }
                            }
                        }
                        int mitad = contador / 2;
                        Console.WriteLine("Nota mediana: " + notas[mitad]);
                        Console.WriteLine("Nota menor: " + notas[contador]);
                        Console.WriteLine("Nota mayor: " + notas[0]);

                        //Moda

                        int maximoNumRepeticiones = 0;
                        for (int i = 0; i <= contador; i++)
                        {
                            int numRepeticiones = 0;
                            for (int j = 0; j <= contador; j++)
                            {
                                if (notas[i] == notas[j])
                                {
                                    numRepeticiones++;
                                }
                                if (numRepeticiones > maximoNumRepeticiones)
                                {
                                    moda = notas[i];
                                    maximoNumRepeticiones = numRepeticiones;
                                }
                            }
                        }

                        Console.WriteLine("Nota moda: " + moda);
                        Console.Write("Presione ENTER para continuar");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.ReadLine();
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        Console.WriteLine("Creditos:");
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                        Console.WriteLine("Nombres:                             Carnés:                    Carreras:");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("Maria Fernanda Valdez                2422922                   Ingenieria Industrial");
                        Console.WriteLine("Julio José Lopez                     1030021                   Ingenieria Civil");
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        Console.WriteLine("A) Regresar a la pantalla de Inicio");
                        Console.WriteLine("B) Terminar Juego");
                        Console.ForegroundColor = ConsoleColor.White;
                        respuesta = Console.ReadLine();
                        if (respuesta.Equals("A"))
                        {
                            contador++;
                            respuestasBuenas = 0;
                            respuestasMalas = 0;
                            menu = "PantallaPrincipal";
                        }
                        else
                        {
                            Environment.Exit(0);
                        }
                        break;
                }
            }
        }
    }
}
