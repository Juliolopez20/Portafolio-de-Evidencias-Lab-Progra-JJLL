﻿using System;

namespace Ejercicio_Laboratorio
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo ");
            Console.WriteLine("soy " + nombre);

            /* La diferencia es que console.writeline compila una sola linea de texto y 
             * luego hace un salto de texto, en cambio console.write 
             * lo copila en una sola linea sin hacer salto alguno*/

            Console.Write("Hola Mundo ");
            Console.Write("soy " + nombre);
            Console.ReadKey();
        }
    }
}
