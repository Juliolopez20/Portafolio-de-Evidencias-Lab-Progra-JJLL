﻿using System;

namespace programa_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double _numero1, _numero2, suma, resta, div, multi, mod;
            Console.WriteLine(" operaciones ");
            Console.WriteLine(" Ingresar dos valores numericos para las operaciones");

            Console.WriteLine("Ingresar valor 1:");
            _numero1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingresar valor 2:");

            _numero2 = Convert.ToDouble(Console.ReadLine());
            suma = Convert.ToDouble(_numero1 + _numero2);
            resta = Convert.ToDouble(_numero1 - _numero2);
            multi = Convert.ToDouble(_numero1 / _numero2);
            div = Convert.ToDouble(_numero1 * _numero2);
            mod = Convert.ToDouble(_numero1 % _numero2);


            Console.WriteLine(_numero1 + " + " + _numero2 + " = " + suma);
            Console.WriteLine(_numero1 + " - " + _numero2 + " = " + resta);
            Console.WriteLine(_numero1 + " / " + _numero2 + " = " + div);
            Console.WriteLine(_numero1 + " * " + _numero2 + " = " + multi);
            Console.WriteLine(_numero1 + " % " + _numero2 + " = " + mod);


            Console.WriteLine(" operaciones booleanas");
            if (_numero1 < _numero2)
            {
                Console.WriteLine(_numero1 + "<" + _numero2);
            }
            if (_numero1 > _numero2)
            {
                Console.WriteLine(_numero1 + ">" + _numero2);
            }
            if (_numero1 == _numero2)
            {
                Console.WriteLine(_numero1 + "=" + _numero2);

            }






            Console.WriteLine(" Jerarquía de operaciones");
            Console.WriteLine("A continuación se le solicitará que ingrese 3 valores, con estos valores se harás diversas operaciones aritméticas");
            double a, b, c, d, e, f;
            double g;
            Console.WriteLine("Ingrese su primer valor");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese su segundo valor");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese su tercero valor");
            c = Convert.ToInt32(Console.ReadLine());

            d = a * b + c;
            Console.WriteLine(a + "*" + b + "+" + c + "=" + d);

            e = a * (b + c);
            Console.WriteLine(a + "*(" + b + "+" + c + ")=" + e);

            f = a / (b * c);
            Console.WriteLine(a + "/(" + b + "*" + c + ")=" + f);

            g = ((3 * a) + (2 * b)) / (c * c);
            Console.WriteLine("((3)" + a + "+(2)" + b + ")/" + c * c + "=" + g);

            Console.WriteLine("El resultado de la primera operación es: " + d);
            Console.WriteLine("El resultado de la segunda  operación es: " + e);
            Console.WriteLine("El resultado de la tercera operación es: " + f);
            Console.WriteLine("El resultado de la cuarta operación es: " + g);





            try
            {
                Console.WriteLine("Ejercicio de formula cuadratica");

                double a1, b1, c1, d1, e1, f1, g1, h1;
                Console.WriteLine("Ingresar primer valor");
                a1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Ingresar segundo valor");
                b1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Ingresar tercer valor ");
                c1 = Convert.ToDouble(Console.ReadLine());






                h1 = 4 * a1 * c1;
                d1 = (b1 * b1) - h1;
                e1 = Math.Sqrt(d1);
                f1 = -b1 + d1 / 2 * a1;
                g1 = -b1 - d1 / 2 * a1;
                if (e1 >= 0)
                {
                    Console.WriteLine("El resultado es: " + f1);
                    Console.WriteLine("El resultado es: " + g1);
                    Console.WriteLine(e1);

                }
                else
                {
                    Console.WriteLine("El resultado de la ecuación cuadrática no es posible calcularse");
                }



            }
            catch
            {
                Console.WriteLine("Error la operacion ingresada con los valores solicitados no es valida");
            }
        }
    }
}