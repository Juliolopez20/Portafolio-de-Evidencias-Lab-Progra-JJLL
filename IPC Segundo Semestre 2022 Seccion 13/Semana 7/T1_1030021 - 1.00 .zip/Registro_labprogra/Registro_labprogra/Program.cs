﻿using System;

namespace Registro_labprogra
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");

            string _nombre;
            string _carrera;
            int _edad;
            int _carne;


            Console.WriteLine("Ingrese su nombre completo");
            _nombre =Console.ReadLine();

            Console.WriteLine("Ingrese su edad");
            _edad = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Indique en que carrera se encuentra");
            _carrera = Console.ReadLine();

            Console.WriteLine("Ingrese su numero de carne");
            _carne = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Soy " + _nombre + " tengo " + _edad + " años y estudio en la carrera de " + _carrera + " mi numero de carne es " + _carne);
            Console.ReadKey();
        }
    }
}
