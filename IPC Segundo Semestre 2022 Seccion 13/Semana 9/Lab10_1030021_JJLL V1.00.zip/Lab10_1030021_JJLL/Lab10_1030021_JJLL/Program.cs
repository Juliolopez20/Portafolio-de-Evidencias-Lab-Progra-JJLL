﻿using System;

namespace Lab10_1030021_JJLL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio Lab10");

            
            double r, pi;
            

            
            pi = 3.141592;
            r = 0;

           
            Console.WriteLine("Ingresar el valor del radio: ");
            SolicitarDatos();
            double resultadoperimetro = ObtenerPerimetro (r);
            double resultadoarea = ObtenerArea(r);
            double resultadovolumen = ObtenerVolumen(r);

            Console.WriteLine("El valor del perimetro es : " + resultadoperimetro.ToString());
            Console.WriteLine("El valor del area es: " + resultadoarea.ToString());
            Console.WriteLine("El valor del volumen es : " + resultadovolumen.ToString());

           

     
            void SolicitarDatos()
            {
                r = Convert.ToDouble(Console.ReadLine());
                
            }

   
            double ObtenerPerimetro(double perimetro)
            {
                
                perimetro  = 2*pi * r;
                return perimetro;
            }

        
            double ObtenerArea(double area)
            {
                area = pi * r * r;
                return area;
            }

            double ObtenerVolumen(double volumen)
            {
                volumen = 4*(pi*Math.Pow(r,3))/3;
                return volumen;
            }


        }
    }

}
