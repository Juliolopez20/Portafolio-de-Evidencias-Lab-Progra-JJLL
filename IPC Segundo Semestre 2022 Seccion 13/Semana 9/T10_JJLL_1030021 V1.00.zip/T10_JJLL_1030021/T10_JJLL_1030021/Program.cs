﻿using System;

namespace T10_JJLL_1030021
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Ingresar el valor del cateto del triangulo: ");
            double catetoA = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Ingresarlos grados del ángulo que es su opuesto: ");
            double anguloOpuestoA = Convert.ToInt16(Console.ReadLine());

            
            Triangulo triangulo = new Triangulo(catetoA, anguloOpuestoA);
            Console.WriteLine("El cateto A tiene un valor de : " + triangulo.ObtenerCatetoA().ToString());

            Console.WriteLine("El cateto B tiene un valor de : " + triangulo.ObtenerCatetoB().ToString());

            Console.WriteLine("La hipotenusa vale : " + triangulo.ObtenerHipotenusa().ToString());

            Console.WriteLine("A tiene un ángulo opuesto de: " + triangulo.ObtenerAnguloOpuestoA().ToString());

            Console.WriteLine("B tiene un ángulo opuesto de: " + triangulo.ObtenerAnguloOpuestoB().ToString());

            Console.WriteLine("El area del triangulo es de:  " + triangulo.ObtenerArea().ToString());
        }
    }


   // Comenzamos a ver con la Ingeniera clases entonces determine por aparte una clase para los procesos del triangulo rectangulo como tal.
    class Triangulo
    {
        
        private double catetoA;
        private double anguloOpuestoA;

        public Triangulo(double cateto, double angulo)
        {
            catetoA = cateto;
            anguloOpuestoA = angulo;
        }
        
        public double ObtenerCatetoA()
        {
           
            return Math.Round(catetoA, 3);
        }
        public double ObtenerCatetoB()
        {
           
            double catetoB = catetoA * Math.Tan(anguloOpuestoA);
            return Math.Round(catetoB, 3);
        }

        public double ObtenerAnguloOpuestoA()
        {

            return Math.Round(anguloOpuestoA, 3);
        }
        public double ObtenerAnguloOpuestoB()
        {

            double anguloOpuestoB = 90 - anguloOpuestoA;
            return Math.Round(anguloOpuestoB, 3);
        }
        public double ObtenerHipotenusa()
        {
            
            double hipotenusa = Math.Sqrt(Math.Pow(catetoA, 2) + Math.Pow(ObtenerCatetoB(), 2));
            return Math.Round(hipotenusa, 3);
        }
       
        public double ObtenerArea()
        {
            
            double area = (catetoA * ObtenerCatetoB()) / 2;
            return Math.Round(area, 3);
        }
    }


    


}
