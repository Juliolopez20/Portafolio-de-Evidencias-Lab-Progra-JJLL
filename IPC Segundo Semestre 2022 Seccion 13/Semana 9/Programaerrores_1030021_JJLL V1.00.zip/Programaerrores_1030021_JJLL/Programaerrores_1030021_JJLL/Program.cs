﻿using System;

namespace Programa_errores_1030021
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1:");
            /*
             * Agregue un comentario con los nombres y números de carnet los miembros de la pareja*/
            Console.WriteLine("Instrucción 1: Encuentre los errores y haga que el programa corra.");
            Console.WriteLine("////");
            Console.WriteLine("////");
            Console.WriteLine("////");
            Console.WriteLine("////");
            Console.WriteLine("");
            Console.WriteLine("Presione una tecla para continuar..");
            Console.ReadKey();
            Console.Clear();
            //Ejemplos de variables con diferentes tipos
            int miNumero = 9;
            double miDecimal = 8.99;
            char miLetra = 'A';
            bool miBooleano = false;
            string HelloWorld;

            //variables
            string NombreUsuario;
            int edadUsuario;
            string carnetUsuario;
            //
            //
            // PROGRAMA 1: calcular si usuario mayor de edad
            // Instrucción: Elabore un diagrama de flujo que
            // refleje el funcionamiento del programa 1.
            //
            //
            Console.WriteLine("Programa: calcular si usuario mayor de edad.");
            Console.WriteLine("Ingrese su nombre:");
            NombreUsuario = Console.ReadLine();
            Console.WriteLine("Ingrese edad:");
            edadUsuario = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Ingrese su carnet:");
            carnetUsuario = Console.ReadLine();

            Console.WriteLine("");
            Console.Write("Mensaje: El usuario con nombre: ");
            Console.Write(NombreUsuario);
            Console.Write(" y carnet: ");
            Console.Write(carnetUsuario);

            if (edadUsuario >= 18)
            {
                Console.Write(". Es mayor de edad.");
            }
            else
            {
                Console.Write(". Es menor de edad.");
            }
            Console.WriteLine("");
            //
            //
            // FIN PROGRAMA 1
            // 
            //
            //
            Console.WriteLine("");
            Console.WriteLine("Presione una tecla para continuar..");
            Console.ReadKey();
            Console.Clear();
            /*
             * PROGRAMA 2: verificar email y password.
             * Instrucción: Elabore un diagrama de flujo que refleje el funcionamiento del programa 1.
             * 
             */
            Console.WriteLine("Programa: log in.");
            string emailUsuario2 = "";
            Console.WriteLine("Ingrese su email");
            emailUsuario2 = Console.ReadLine();
            Console.WriteLine("Ingrese su contraseña");
            string contrasenaUsuario2 = Console.ReadLine();

            if (emailUsuario2.Length <= 0)
            {
                if (emailUsuario2 == "")
                {
                    if (emailUsuario2 == "admin@gmail.com" && (contrasenaUsuario2 == "456" || contrasenaUsuario2 == "zxc"))
                    {
                        Console.WriteLine("Usuario es valido.");
                    }
                }
                else
                    Console.WriteLine("Usuario y/o contraseña no son correctos.");
            }

            //
            //
            // FIN PROGRAMA 2
            // 
            //
            //
            Console.WriteLine("");
            Console.WriteLine("Presione una tecla para salir..");
            Console.ReadKey();
            Console.Clear();
        }



    }
}
