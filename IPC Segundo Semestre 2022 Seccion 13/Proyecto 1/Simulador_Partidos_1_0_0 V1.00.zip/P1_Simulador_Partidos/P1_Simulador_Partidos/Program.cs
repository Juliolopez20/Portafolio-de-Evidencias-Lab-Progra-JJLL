﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P1_Simulador_Partidos
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var EquiposArray = new Equipos[8];
            var random = new Random();
            for (int i = 0; i < EquiposArray.Count(); i++)
            {
                EquiposArray[i]=new Equipos();
            }
            var IdEquipo1 = 0;
            var IdEquipo2 = 0;
            //seleccion 
            for (int i = 0; i < 25; i++)
            {
                IdEquipo1 = random.Next(0, EquiposArray.Length);
                if (EquiposArray[IdEquipo1].Seleccionado == false)
                {
                    IdEquipo2 = random.Next(0, EquiposArray.Length - 1);
                    while (IdEquipo2 == IdEquipo1)
                    {
                        IdEquipo2 = random.Next(0, EquiposArray.Length - 1);
                    }
                    while (EquiposArray[IdEquipo2].Seleccionado == true)
                    {
                        IdEquipo2 = random.Next(0, EquiposArray.Length - 1);

                    }
                    if (EquiposArray[IdEquipo2].Seleccionado == false)
                    {
                        EquiposArray[IdEquipo1].idContricante = IdEquipo2;
                        EquiposArray[IdEquipo1].Seleccionado = true;

                        EquiposArray[IdEquipo2].idContricante = IdEquipo1;
                        EquiposArray[IdEquipo2].Seleccionado = true;
                    }
                }
            }

            bool Menu_Equipos = true;
            double calcularPoderDelEquipo(int PG, int PP, int PE, int etapa)
            {
                double poder = ((PG * 0.7) - (PP * 0.2) + (PE * 0.4)) / etapa;
                poder = Math.Round(poder, 3);
                return poder;
            }
            while (Menu_Equipos == true)
            {
                Console.WriteLine("1. Ingresar datos de Equipos");
                Console.WriteLine("2. Editar Equipos");
                Console.WriteLine("3. Mostrar Equipos");
                Console.WriteLine("4. Simular Partidos");
                int Opccion = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (Opccion)
                {
                    case 1:
                        IngresarEquiposArray();
                        break;
                    case 2:
                        ModificarEquipos();
                        break;
                    case 3:
                        MostrarEquipos();
                        break;
                    case 4:
                        Partidos();
                        break;
                }
            }
            void IngresarEquiposArray()
            {
                for (int i = 0; i < EquiposArray.Count(); i++)
                {
                    int SumatoriaPoderEquipo = 0;
                    do
                    {
                        
                    Console.WriteLine($"Ingrese el Nombre del equipo #{i}");
                    Console.WriteLine("Asegurese que la suma de los partidos sea igual a 4");
                    Console.WriteLine("Ingrese los partidos ganados, perdidos y empatados");
                    EquiposArray[i].Nombre_Equipo = Console.ReadLine();
                    EquiposArray[i].P_G = Convert.ToInt32(Console.ReadLine());
                    EquiposArray[i].P_E = Convert.ToInt32(Console.ReadLine());
                    EquiposArray[i].P_P = Convert.ToInt32(Console.ReadLine());
                    SumatoriaPoderEquipo = EquiposArray[i].P_G + EquiposArray[i].P_E + EquiposArray[i].P_P;
                    EquiposArray[i].Faces_Etapas = 5;                    
                    Console.Clear();    
                } while (SumatoriaPoderEquipo != 4) ;

            }
        }

            void ModificarEquipos()
            {
                Console.WriteLine("Que equipo desea modificar");
                string Equipo = Console.ReadLine();

                if (Equipo == EquiposArray[0].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[0].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[0].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[0].P_P = int.Parse(Console.ReadLine());
                    }
                }
                if (Equipo == EquiposArray[1].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[1].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[1].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[1].P_P = int.Parse(Console.ReadLine());
                    }
                }
                if (Equipo == EquiposArray[2].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[2].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[2].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[2].P_P = int.Parse(Console.ReadLine());
                    }
                }
                if (Equipo == EquiposArray[3].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[3].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[3].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[3].P_P = int.Parse(Console.ReadLine());
                    }
                }
                if (Equipo == EquiposArray[4].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[4].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[4].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[4].P_P = int.Parse(Console.ReadLine());
                    }
                }
                if (Equipo == EquiposArray[5].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[5].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[5].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[5].P_P = int.Parse(Console.ReadLine());
                    }
                }
                if (Equipo == EquiposArray[6].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[6].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[6].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[6].P_P = int.Parse(Console.ReadLine());
                    }
                }
                if (Equipo == EquiposArray[7].Nombre_Equipo)
                {
                    Console.WriteLine("Que desea modificar");
                    string Cambio = Console.ReadLine();
                    if (Cambio == "PG")
                    {
                        Console.WriteLine("Ingrese los PG");
                        EquiposArray[7].P_G = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PE")
                    {
                        Console.WriteLine("Ingrese los PE");
                        EquiposArray[7].P_E = int.Parse(Console.ReadLine());
                    }
                    else if (Cambio == "PP")
                    {
                        Console.WriteLine("Ingrese los PP");
                        EquiposArray[7].P_P = int.Parse(Console.ReadLine());
                    }
                }
            }
            void MostrarEquipos()
            {
                for (int i = 0; i < EquiposArray.Length; i++)
                {
                    Console.WriteLine($"Equipo{i}:" + EquiposArray[i].Nombre_Equipo);
                }
                Console.ReadKey();
                Console.Clear();
            }
            void Partidos()
            {
                Console.WriteLine("Equipos a enfrentaser en los cuartos de final");
                var contado = 0;
                foreach (var item in EquiposArray)
                {
                    Console.WriteLine($"Equipo {contado} va contra {item.idContricante}");
                    contado++;
                }
                Console.WriteLine();
                Console.ReadKey();
                Console.Clear();
                Console.WriteLine("Fase de cuartos de final a final");
                Console.ReadKey();
                SimularCuartosdeFinal();

            }
            void SimularCuartosdeFinal()
            {
                
                    double PoderEquipo1 = calcularPoderDelEquipo(EquiposArray[IdEquipo1].P_G, EquiposArray[IdEquipo1].P_E, EquiposArray[IdEquipo1].P_P, EquiposArray[IdEquipo1].Faces_Etapas);
                    int GolesEquipo1 = 0;
                    for (int j = 1; j < 6; j++)
                    {
                        Random random = new Random();
                        double numeroRandom = random.NextDouble();
                        if (numeroRandom < PoderEquipo1)
                        {
                            GolesEquipo1++;
                        }
                    }

                    double PoderEquipo2 = calcularPoderDelEquipo(EquiposArray[IdEquipo2].P_G, EquiposArray[IdEquipo2].P_E, EquiposArray[IdEquipo2].P_P, EquiposArray[IdEquipo1].Faces_Etapas);
                    int GolesEquipo2 = 0;
                    for (int j = 1; j < 6; j++)
                    {
                        Random random = new Random();
                        double numeroRandom = random.NextDouble();
                        if (numeroRandom < PoderEquipo2)
                        {
                            GolesEquipo2++;
                        }
                    }

                    if (GolesEquipo1 == GolesEquipo2)
                    {
                        for (int j = 1; j < 3; j++)
                        {
                            Random random = new Random();
                            double numeroRandom = random.NextDouble();
                            if (numeroRandom < PoderEquipo1)
                            {
                                GolesEquipo2++;
                            }

                        }
                    }
                    else if (GolesEquipo1 > GolesEquipo2)
                    {
                        Console.WriteLine("Ganó " + EquiposArray[IdEquipo1].Nombre_Equipo);
                        EquiposArray[IdEquipo1].Faces_Etapas++;
                    }
                    else
                    {
                        Console.WriteLine("Ganó " + EquiposArray[IdEquipo2].Faces_Etapas);
                        EquiposArray[IdEquipo2].Faces_Etapas++;
                    }
                
            }


        }
    }
}
