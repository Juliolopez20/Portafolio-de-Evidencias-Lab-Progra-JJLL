﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_Simulador_Partidos
{
    internal class Equipos
    {
        public Equipos()
        {
            P_G = 0;
            P_E = 0;
            P_P = 0;
            idContricante = 0;
            Seleccionado = false;
            Faces_Etapas = 5;
        }

        public string Nombre_Equipo= String.Empty;

        public int P_G = 0;
        public int P_E = 0;
        public int P_P = 0;

        public int  idContricante =0;
        public bool Seleccionado = false;


        public int  Faces_Etapas = 0;
    }
}
