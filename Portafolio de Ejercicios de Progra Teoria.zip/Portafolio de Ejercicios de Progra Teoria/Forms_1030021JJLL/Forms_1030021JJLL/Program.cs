﻿// See https://aka.ms/new-console-template for more information
using Internal;
using System;

Console.WriteLine("Ejercicio de Forms realizado en consila");
//Ingeniera aca le hago la entrega de lo que consegui hacer en consola, me costo un poco pero fue lo mejor que pude por que si trate de incorporar las funciones de forms para al menos conseguir armar el programa.
public partial class Form1 : Forms
{

    cFormulario _objFormulario = new cFormulario();
    public Form1()
    {
        InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void label2_Click(object sender, EventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
        string _nombre, _genero, _nacionalidad, _carrera;
        int _edad;

        _nombre = textBox1.Text;
        _genero = textBox2.Text;
        _nacionalidad = textBox3.Text;
        _carrera = textBox4.Text;
        _edad = int.Parse(textBox5.Text);



    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {


    }
    internal class cFormulario
    {
        string nombrecompleto, genero, nacionalidad, carrera;
        int edad;


        public cFormulario()
        {
            string nombrecompleto, genero, nacionalidad, carrera;
            int edad;
            nombrecompleto = " ";
            genero = " ";
            nacionalidad = "";
            carrera = " ";
            edad = 0;
        }


        public string getNombrecompleto()
        {
            return nombrecompleto;
        }
        public void setNombrecompleto(string _nombrecompleto)
        {
            _nombrecompleto = nombrecompleto;
        }
        public void setNacionalidad(string _nacionalidad)
        {
            _nacionalidad = nacionalidad;
        }
        public string getgenero()
        {
            return genero;
        }
        public void setGenero(string _genero)
        {
            _genero = genero;
        }
        public int getEdad()
        {
            return edad;
        }
        public string getNacionalidad()
        {
            return nacionalidad;
        }

        public void setEdad(int _edad)
        {
            _edad = edad;

        }
        public string getCarrera()
        {
            return carrera;
        }
        public void setCarrera(string _carrera)
        {
            _carrera = carrera;

        }


    }
}



