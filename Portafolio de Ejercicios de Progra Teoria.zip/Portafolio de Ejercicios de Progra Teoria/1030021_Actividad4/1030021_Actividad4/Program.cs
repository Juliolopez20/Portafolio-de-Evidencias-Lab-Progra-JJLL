﻿using System;

namespace _1030021_Actividad4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Activiudad 4 Semana 8");

            string  palabra1, palabra2, palabra3, palabra4, palabra5, palabra6, palabra7, palabra8, palabra9, palabra10, ;

            Console.WriteLine("Ingrese palabra numero 1");
            palabra1 = Console.ReadLine().ToString ();

            Console.WriteLine("Ingrese palabra numero 2");
            palabra2 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 3");
            palabra3 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 4");
            palabra4 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 5");
            palabra5 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 6");
            palabra6 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 7");
            palabra7 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 8");
            palabra8 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 9");
            palabra9 = Console.ReadLine().ToString();

            Console.WriteLine("Ingrese palabra numero 10");
            palabra10 = Console.ReadLine().ToString();

            //declarar condiciones 
         // me confundi y tupi cuando debia declarar variables por que no tenia claro como expecificar o registrar mas bien las variables en especifico pero investigare para finalizar el codigo

            
        }
    }
}