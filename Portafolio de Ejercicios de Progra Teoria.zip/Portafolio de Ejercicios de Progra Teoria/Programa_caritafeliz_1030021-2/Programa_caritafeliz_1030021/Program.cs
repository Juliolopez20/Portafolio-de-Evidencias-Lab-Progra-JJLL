﻿using System;

namespace Programa_caritafeliz_1030021
{
    class Program
    {
        static void Main(string[] args)
        {
            //Esta fue mi primera solucion de la tarea 4 de la carita feliz de forma sencilla,
            // pero luego tuve complicaciones para terminarla con la clase.

            Console.WriteLine("*********************");
            Console.WriteLine("*                   *");
            Console.WriteLine("*    *         *    *");
            Console.WriteLine("*   * *       * *   *");
            Console.WriteLine("*  * * *     * * *  *");
            Console.WriteLine("*                   *");
            Console.WriteLine("*                   *");
            Console.WriteLine("*    ***********    *");
            Console.WriteLine("*    *         *    *");
            Console.WriteLine("*    ***********    *");
            Console.WriteLine("*********************");

            Console.ReadKey();
        }
    }
}
