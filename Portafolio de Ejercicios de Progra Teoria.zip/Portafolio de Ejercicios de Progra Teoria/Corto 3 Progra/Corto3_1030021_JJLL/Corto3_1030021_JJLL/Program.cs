﻿// See https://aka.ms/new-console-template for more information


int opcion = 0;
int Menu = 0;


do
{
    Console.ResetColor();
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine("-------Menu de Restaurante-------");
    Console.WriteLine("1. Ver el menu");
     Console.WriteLine("2. Seleccionar el menu deseado");
     Console.WriteLine("3. Mostrar el total a pagar");
     Console.WriteLine("4. Desea agregar mas menus?");
     Console.WriteLine(" 5. Salir ");
        
       
      
         
    Console.WriteLine("Ingrese su opcion deseada");
    opcion = Convert.ToInt32(Console.ReadLine());

    switch (opcion)
    {
        case 1:
            Console.WriteLine(" Los platillos de hoy son los siguientes:");
            Console.WriteLine(" 1.Hamburguesa Q24.00");
            Console.WriteLine(" 2.Pizza Q35.00");
            Console.WriteLine(" 3.Pasta Q28.00");
            Console.WriteLine(" 4.Ensalada Q22.00");
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            break;
        case 2:
            
            do
            {
                Console.WriteLine(" 1.Hamburguesa Q24.00");
                Console.WriteLine(" 2.Pizza Q35.00");
                Console.WriteLine(" 3.Pasta Q28.00");
                Console.WriteLine(" 4.Ensalada Q22.00");
                Console.WriteLine("Ingrese su menu deseado");
                Menu = Convert.ToInt32(Console.ReadLine());

                switch (Menu)
                {
                    case 1:
                        Console.WriteLine("A escogido la Hamburguesa");
                        Console.WriteLine("-- QUE LA DISFRUTE :) --");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;

                    case 2:
                        Console.WriteLine("A escogido la Pizza");
                        Console.WriteLine("-- QUE LA DISFRUTE :) --");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;

                    case 3:
                        Console.WriteLine("A escogido la Pasta");
                        Console.WriteLine("-- QUE LA DISFRUTE :) --");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;

                    case 4:
                        Console.WriteLine("A escogido la Ensalada");
                        Console.WriteLine("-- QUE LA DISFRUTE :) --");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;
                    default:
                        Console.WriteLine("Ingrese porfavor una de las opciones del menu");
                        break;
                }
                
            }
            while (Menu != 4);

            break;


        case 3:

            if(Menu == 1)
            {
                Console.WriteLine("Su total a pagar es de  Q 24.00");
            }
            if(Menu == 2)
            {
                Console.WriteLine("Su total a pagar es de  Q 35.00");
            }
            if (Menu == 3)
            {
                Console.WriteLine("Su total a pagar es de  Q 28.00");
            }
            if (Menu == 4)
            {
                Console.WriteLine("Su total a pagar es de  Q 22.00");
            }

            break;


        case 4:
            int canthamburguesa, cantpizza, cantpasta, cantensalada;

            int preciohamburguesa = 24, preciopizza = 35, preciopasta = 24, precioensalada = 28;

            int Pagocompleto;

            Console.Write("Cuantas Hamburguesas desea ordenar");
            canthamburguesa = Int32.Parse (Console.ReadLine());
            Console.Write("Cuantas pizzas desea ordenar");
            cantpizza  = Int32.Parse(Console.ReadLine());
            Console.Write("Cuantas pastas desea ordenar");
            cantpasta  = Int32.Parse(Console.ReadLine());
            Console.Write("cuantas ensaladas desea ordenar");
            cantensalada  = Int32.Parse(Console.ReadLine());

            Pagocompleto = (canthamburguesa * preciohamburguesa) + (cantpizza * preciopizza) + (cantpasta * preciopasta) + (cantensalada * precioensalada);

            Console.WriteLine("El total a pagar es de: " + Pagocompleto );


            break;


        case 5:
            Console.WriteLine("----GRACIAS POR SU VISITA---");
            Console.WriteLine("");
            Console.WriteLine("");
            break;

        default:
            Console.WriteLine("Ingrese una opcion valida entre la 1 y la 4");
            break;

    }
    

}
while (opcion != 5);

